import numpy as np

def lu_decomposition(A):
    n = len(A)
    L = np.zeros((n, n))
    U = np.zeros((n, n))
    for i in range(n):
        # Upper triangular matrix
        for k in range(i, n):
            sum_upper = 0
            for j in range(i):
                sum_upper += L[i][j] * U[j][k]
            U[i][k] = A[i][k] - sum_upper
        # Lower triangular matrix
        for k in range(i, n):
            if i == k:
                L[i][i] = 1
            else:
                sum_lower = 0
                for j in range(i):
                    sum_lower += L[k][j] * U[j][i]
                L[k][i] = (A[k][i] - sum_lower) / U[i][i]
    return L, U

def forward_substitution(L, b):
    n = len(L)
    y = np.zeros(n)
    for i in range(n):
        sum_lower = 0
        for j in range(i):
            sum_lower += L[i][j] * y[j]
        y[i] = b[i] - sum_lower
    return y

def backward_substitution(U, y):
    n= len(U)
    x = np.zeros(n)
    for i in range(n-1, -1, -1):
        sum_upper = 0
        for j in range(i+1, n):
            sum_upper += U[i][j] * x[j]
        x[i] = (y[i] - sum_upper) / U[i][i]
    return x

A=np.array([[2, -1, 1], [-4,6,3], [-4, -2, 8]], dtype=float)
b=np.array([-2,9,-5], dtype=float)
L,U=lu_decomposition(A)
y=forward_substitution(L,b)
x=backward_substitution(U,y)
print("Matrix A:")
print(A)
print("\nLower Triangular Matrix L:")
print(L)
print("\nUpper Triangular Matrix U:")
print(U)
print("\nIntermediate Solution vector y:")
print(y)
print("\nFinal Solution vector x:")
print(x)